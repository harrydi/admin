<?php 
class Envista_Banner_Block_Adminhtml_Renderer_Wysiwyg extends Mage_Adminhtml_Block_Catalog_Helper_Form_Wysiwyg{

}
?>
<?php   
class Omniesolutions_Catalogdoc_Block_Index extends Mage_Core_Block_Template{   





}
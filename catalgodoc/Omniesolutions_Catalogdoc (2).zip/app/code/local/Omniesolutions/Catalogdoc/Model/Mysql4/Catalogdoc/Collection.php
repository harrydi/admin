<?php
    class Omniesolutions_Catalogdoc_Model_Mysql4_Catalogdoc_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("catalogdoc/catalogdoc");
		}

		

    }
	 
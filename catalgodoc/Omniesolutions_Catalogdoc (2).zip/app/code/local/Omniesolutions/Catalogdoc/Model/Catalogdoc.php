<?php

class Omniesolutions_Catalogdoc_Model_Catalogdoc extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("catalogdoc/catalogdoc");

    }

}
	 
<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
DROP TABLE IF EXISTS {$this->getTable('leaders')};
	CREATE TABLE {$this->getTable('leaders')} (
	  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
	  `name` varchar(50) NOT NULL DEFAULT '',
	  `image` varchar(50) NOT NULL DEFAULT '',
	  `description` text NOT NULL DEFAULT '',
	  `linkedin` varchar(250) NOT NULL DEFAULT '',
	  `position` varchar(50) NOT NULL DEFAULT '',
	  `creation_time` datetime DEFAULT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SQLTEXT;

$installer->run($sql);
//demo 
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 
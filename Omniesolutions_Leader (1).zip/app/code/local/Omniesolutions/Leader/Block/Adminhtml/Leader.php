<?php


class Omniesolutions_Leader_Block_Adminhtml_Leader extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_leader";
	$this->_blockGroup = "leader";
	$this->_headerText = Mage::helper("leader")->__("Leader Manager");
	$this->_addButtonLabel = Mage::helper("leader")->__("Add New Item");
	parent::__construct();
	
	}

}
<?php
class Omniesolutions_Leader_Block_Adminhtml_Leader_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("leader_form", array("legend"=>Mage::helper("leader")->__("Item information")));

				
						$fieldset->addField("name", "text", array(
						"label" => Mage::helper("leader")->__("Name"),
						"name" => "name",
						));
									
						$fieldset->addField('image', 'image', array(
						'label' => Mage::helper('leader')->__('Image'),
						'name' => 'image',
						'note' => '(*.jpg, *.png, *.gif)',
						));
						$fieldset->addField("linkedin", "text", array(
						"label" => Mage::helper("leader")->__("Linked In"),
						"name" => "linkedin",
						));
					
						$fieldset->addField("position", "text", array(
						"label" => Mage::helper("leader")->__("Position"),
						"name" => "position",
						));
					

				if (Mage::getSingleton("adminhtml/session")->getLeaderData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getLeaderData());
					Mage::getSingleton("adminhtml/session")->setLeaderData(null);
				} 
				elseif(Mage::registry("leader_data")) {
				    $form->setValues(Mage::registry("leader_data")->getData());
				}
				return parent::_prepareForm();
		}
}

<?php   
class Omniesolutions_Leader_Block_Index extends Mage_Core_Block_Template{   





}
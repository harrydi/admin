<?php

class Omniesolutions_Leader_Model_Leader extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("leader/leader");

    }

}
	 
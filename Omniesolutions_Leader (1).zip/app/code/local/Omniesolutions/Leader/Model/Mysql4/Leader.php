<?php
class Omniesolutions_Leader_Model_Mysql4_Leader extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("leader/leader", "id");
    }
}
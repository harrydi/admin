<?php
class Webtex_Core_Model_Core extends Mage_Core_Model_Abstract
{
 
}
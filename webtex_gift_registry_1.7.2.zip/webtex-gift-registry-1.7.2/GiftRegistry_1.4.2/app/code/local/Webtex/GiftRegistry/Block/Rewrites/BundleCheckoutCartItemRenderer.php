<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Bundle
 * @copyright   Copyright (c) 2008 Irubin Consulting Inc. DBA Varien (http://www.varien.com)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * Shopping cart item render block
 *
 * @category    Mage
 * @package     Mage_Bundle
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Webtex_GiftRegistry_Block_Rewrites_BundleCheckoutCartItemRenderer extends Mage_Bundle_Block_Checkout_Cart_Item_Renderer
{
    public function getRegistryTitle()
    {
        $customOptions = $this->getItem()->getOptionsByCode();
        if ($customOptions['info_buyRequest']) 
        {
            $info_buyRequest = unserialize($customOptions['info_buyRequest']->getValue());
                            
            $webtex_giftregistry_id = isset($info_buyRequest['webtex_giftregistry_id']) && $info_buyRequest['webtex_giftregistry_id'] ? $info_buyRequest['webtex_giftregistry_id'] : false;       
        }
        
        $answer = '';
        
        if(isset($webtex_giftregistry_id) && $webtex_giftregistry_id)
        {
            $registry = Mage::helper('webtexgiftregistry')->getRegistryById($webtex_giftregistry_id);
            $_array['firstname'] = $registry->getData('firstname');
            $_array['lastname'] = $registry->getData('lastname');
            $_array['cofirstname'] = $registry->getData('co_firstname');
            $_array['colastname'] = $registry->getData('co_lastname');
        
            $url = $this->getUrl('webtexgiftregistry/index/registry', array('id'=>$registry->getData('giftregistry_id')));
        
            $answer = '<a href="'. $url .'">' . $this->__('For') . ' ' . $_array['firstname'] . ' ' . $_array['lastname'];
        
            if($_array['cofirstname'] || $_array['colastname'])
            {
                $answer .= ' ' . $this->__('And') . ' ';
                $answer .= $_array['cofirstname'] . ' ' . $_array['colastname'];
            }
            
            $answer .= ' ' . $this->__('Gift Registry') . '</a>';
        }
        
        return $answer;
    }
}
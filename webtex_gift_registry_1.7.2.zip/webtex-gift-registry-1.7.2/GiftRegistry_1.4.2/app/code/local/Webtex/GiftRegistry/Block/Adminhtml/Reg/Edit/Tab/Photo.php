<?php

class Webtex_Giftregistry_Block_Adminhtml_Reg_Edit_Tab_Photo extends Mage_Adminhtml_Block_Widget_Form
{
    public function _prepareForm()
    {
        $form = new Varien_Data_Form();

        $aData = $this->getFormData();

        $fieldset = $form->addFieldset('form_form', array(
            'legend' => 'Photo' //todo: add localization
        ));

        $fieldset->addField('filename', 'image', array(
            'label' => 'Image',
            'required' => false,
            'name' => 'filename',
            'value' => 'http://v1702.local/media/webtexgiftregistry/resized/123123_1.jpg',
        ));

        $this->setForm($form);
        $form->setValues($aData);
        return parent::_prepareForm();
    }

    private function getFormData()
    {
        $oRegistry = Mage::getSingleton('webtexgiftregistry/session')->getRegistry();

        $aData = array();
        $aData['firstname'] = $oRegistry->getFirstname();
        $aData['lastname'] = $oRegistry->getLastname();
        $aData['maidenname'] = $oRegistry->getMaidenname();
        $aData['email'] = $oRegistry->getEmail();

        return $aData;
    }
}
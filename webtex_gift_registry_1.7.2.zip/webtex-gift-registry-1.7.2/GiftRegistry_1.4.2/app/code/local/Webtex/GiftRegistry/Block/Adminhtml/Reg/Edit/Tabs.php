<?php

class Webtex_Giftregistry_Block_Adminhtml_Reg_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('webtexfiftregistry_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle('Edit');
    }

    protected function _beforeToHtml()
    {

        $this->addTab('registrant', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Registrnat'),
            'title' => Mage::helper('webtexgiftregistry')->__('Registrant'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_registrant')->toHtml(),
        ));

        $this->addTab('coregistrant', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Co-Registrant'),
            'title' => Mage::helper('webtexgiftregistry')->__('Co-Registrant'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_coregistrant')->toHtml(),
        ));

        $this->addTab('event', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Event'),
            'title' => Mage::helper('webtexgiftregistry')->__('Event'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_event')->toHtml(),
        ));

        $this->addTab('shipping', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Shipping Address'),
            'title' => Mage::helper('webtexgiftregistry')->__('Shipping Address'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_address')->toHtml(),
        ));

        $this->addTab('photo', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Photo'),
            'title' => Mage::helper('webtexgiftregistry')->__('Photo'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_photo')->toHtml(),
        ));

        $this->addTab('test', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Registry Status'),
            'title' => Mage::helper('webtexgiftregistry')->__('Registry Status'),
            'content' => $this->getLayout()->createBlock('webtexgiftregistry/adminhtml_reg_edit_tab_status')->toHtml(),
        ));

        /*$this->addTab('test', array(
            'label' => Mage::helper('webtexgiftregistry')->__('Registry Items'),
            'title' => Mage::helper('webtexgiftregistry')->__('Registry Items'),
            'content' => $this->getLayout()->createBlock('adminhtml/sales_order_create_items')->toHtml(),
        ));*/

        return parent::_beforeToHtml();
    }
}